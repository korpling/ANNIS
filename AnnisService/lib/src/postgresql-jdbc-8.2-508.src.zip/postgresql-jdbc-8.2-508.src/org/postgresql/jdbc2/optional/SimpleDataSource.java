/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2005, PostgreSQL Global Development Group
*
* IDENTIFICATION
*   $PostgreSQL: pgjdbc/org/postgresql/jdbc2/optional/SimpleDataSource.java,v 1.5 2005/01/11 08:25:46 jurka Exp $
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGSimpleDataSource;

public class SimpleDataSource extends PGSimpleDataSource
{
}
